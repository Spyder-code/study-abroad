<?php $__env->startSection('role','Super User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-3"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-3"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('danger')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col col-sm text-center">
            <div class="card mt-3">
                <img class="img-thumbnail ml-5 mr-5 mt-3" src="<?php echo e($user->image_path); ?>" style="height:300px" alt="<?php echo e($user->name); ?>">
                <div class="card-body">
                    <ul class="list-group text-left">
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col col-4">
                                    <label for="address">Username</label>
                                </div>
                                <div class="col col-2">
                                    <label for="">:</label>
                                </div>
                                <div class="col">
                                    <?php echo e($user->name); ?>

                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col col-4">
                                    <label for="address">Email</label>
                                </div>
                                <div class="col col-2">
                                    <label for="">:</label>
                                </div>
                                <div class="col">
                                    <?php echo e($user->email); ?>

                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
                <div class="col mt-3">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <h4>Ganti Foto Profil</h4>
                    <hr>
                <form  method="post" action="<?php echo e(url('changeImageUser')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="file" id="img" class="file" name="image"/>
                    <span class="text-danger"><?php echo e($errors->first('images')); ?></span>
                    <input type="hidden" name="oldImage" value="<?php echo e($user->image); ?>">
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <button type="submit" class="btn btn-success float-right mr-5">Change</button>
                </form>
                <h4 class="mt-5">Ganti Password</h4>
                <hr>
                <form class="form-row"  method="post" action="<?php echo e(url('updatePassword')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <div class="col">
                        <div class="form-group">
                            <label for="pass1">Old Password</label>
                            <input type="password" class="form-control" name="oldPassword">
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="pass2">New Password</label>
                            <input type="password" class="form-control" name="newPassword">
                        </div>
                        <button type="submit" class="btn btn-success mb-2 float-right mr-5">Change</button>
                    </div>
                </form>
                <h4 class="mt-2">Ganti Email</h4>
                <hr>
                <form class="form-row"  method="post" action="<?php echo e(url('updateEmail')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <label for="pass1">New Email</label>
                        <div class="form-group d-flex">
                            <input type="text" class="form-control" name="email">
                            <button type="submit" class="btn btn-success mb-2 float-right ml-5">Change</button>
                        </div>
                </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\study-abroad\resources\views/super/profile.blade.php ENDPATH**/ ?>