<?php $__env->startSection('role','Super User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php $__errorArgs = ['nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-3"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger mt-3"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('danger')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col col-sm">
            <div class="card mt-3">
                <div class="card-body">
                    <h1>Tambah Admin</h1>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('addAdmin')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col">
                                <ul class="list-group text-left">
                                    <li class="list-group-item">
                                        <div class="row">
                                            <div class="col col-4">
                                                <label for="address">Name</label>
                                            </div>
                                            <div class="col col-2">
                                                <label for="">:</label>
                                            </div>
                                            <div class="col">
                                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control">
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="row">
                                            <div class="col col-4">
                                                <label for="address">Email</label>
                                            </div>
                                            <div class="col col-2">
                                                <label for="">:</label>
                                            </div>
                                            <div class="col">
                                                <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="col">
                                <ul class="list-group text-left">
                                    <li class="list-group-item">
                                        <div class="row">
                                            <div class="col col-4">
                                                <label for="address">Password</label>
                                            </div>
                                            <div class="col col-2">
                                                <label for="">:</label>
                                            </div>
                                            <div class="col">
                                                <input type="password" name="password" class="form-control">
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="row">
                                            <div class="col col-4">
                                                <label for="address">Confirm Password</label>
                                            </div>
                                            <div class="col col-2">
                                                <label for="">:</label>
                                            </div>
                                            <div class="col">
                                                <input type="password" name="password_confirmation" class="form-control">
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success">Tambahkan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <table class="table table-responsive-sm">
                        <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Email</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td class="d-flex flex-row">
                                <form action="<?php echo e(url('deletePesan')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                    <input type="hidden" name="judul" value="<?php echo e($item->nama); ?>">
                                    <button type="submit" onclick="return confirm('Are You Sure?')" class="ml-2 btn btn-danger">Hapus</button>
                                </form>
                                <form action="<?php echo e(url('deletePesan')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                    <input type="hidden" name="judul" value="<?php echo e($item->nama); ?>">
                                    <button type="submit" onclick="return confirm('Are You Sure?')" class="ml-2 btn btn-info">Reset Password</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>
<script>
    $(function(){
        var table = $('.table').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\study-abroad\resources\views/super/admin.blade.php ENDPATH**/ ?>