<?php $__env->startSection('role','Super User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($message = Session::get('success')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('danger')): ?>
        <div class="row">
            <div class="col mt-3">
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">x</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            </div>
        </div>
    <?php endif; ?>

        <div class="row">
            <div class="col-sm-8">
                <div class="row">
                    <div class="col">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                Pendaftar Lulus
                            </div>
                            <div class="card-body">
                                <table class="table data-table table-responsive-sm">
                                    <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Negara</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $studentL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->negara); ?></td>
                                        <td>
                                            <?php if($item->status == 0): ?>
                                                <span class="badge badge-danger">Belum diverifikasi</span>
                                            <?php elseif($item->status == 1): ?>
                                                <span class="badge badge-warning">Dokumen Salah</span>
                                            <?php elseif($item->status == 2): ?>
                                                <span class="badge badge-success">Verifikasi Suksess</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col mt-5">
                        <div class="card">
                            <div class="card-header bg-danger text-white">
                                Pendaftar Tidak Lulus
                            </div>
                            <div class="card-body">
                                <table class="table data-table table-responsive-sm">
                                    <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Negara</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $studentTL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->negara); ?></td>
                                        <td>
                                            <?php if($item->status == 0): ?>
                                                <span class="badge badge-danger">Belum diverifikasi</span>
                                            <?php elseif($item->status == 1): ?>
                                                <span class="badge badge-warning">Dokumen Salah</span>
                                            <?php elseif($item->status == 2): ?>
                                                <span class="badge badge-success">Verifikasi Suksess</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card mt-5">
                            <div class="card-header bg-primary text-white">
                                List Semua Pendaftar
                            </div>
                            <div class="card-body">
                                <table class="table data-table table-responsive-sm">
                                    <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Negara</th>
                                        <th scope="col">Waktu Daftar</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $allStudent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($item->nama); ?></td>
                                        <td><?php echo e($item->negara); ?></td>
                                        <td><?php echo e(date('d F Y', strtotime($item->created_at))); ?></td>
                                        <td>
                                            <?php if($item->status == 0): ?>
                                                <span class="badge badge-danger">Belum diverifikasi</span>
                                            <?php elseif($item->status == 1): ?>
                                                <span class="badge badge-warning">Dokumen Salah</span>
                                            <?php elseif($item->status == 2): ?>
                                                <span class="badge badge-success">Verifikasi Suksess</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card">
                    <div class="card-header bg-warning text-white">
                        Aktivitas admin terkini
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama admin</th>
                                <th scope="col">Subjek</th>
                                <th scope="col">Keterangan</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                <td><?php echo e($item->user->name); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->subjek); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>
<script>
    $(function(){
        var table = $('.data-table').DataTable({
            responsive:true
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\study-abroad\resources\views/super/laporan.blade.php ENDPATH**/ ?>