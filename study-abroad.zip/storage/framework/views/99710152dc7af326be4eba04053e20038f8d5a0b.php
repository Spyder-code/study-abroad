Hi <strong><?php echo e($name); ?></strong>,
<p><?php echo e($body); ?></p>
<?php /**PATH F:\xampp\htdocs\study-abroad\resources\views/emails.blade.php ENDPATH**/ ?>